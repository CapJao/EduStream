var express = require('express');
var router = express.Router();

/* GET admin. */
router.get('/', function(req, res, next) {
  res.render('admin/loginadm');
});

/* GET dashboard */
router.get('/gerenciamento_curso', function(req, res, next){
  verificarLogin(res);
  res.render('admin/gerenciamento_curso',{admNome : global.adminEmail});
});

//GET CursosNovo
router.get('/cursos_novo', verLogin, function(req, res, next){
  res.render('admin/cursos_novo', {
    admNome : global.admNome,
    mensagem : null,
    sucesso : false
  });
});

/* GET sair */
router.get('/sair', function(req, res, next){
  verificarLogin(res);
  delete global.adminCodigo;
  delete global.adminEmail;
  res.redirect('/admin');
});

/* POST login*/
router.post('/login', async function(req, res, next) {
    const email = req.body.email ;
    const senha = req.body.senha;
  
    const admin = await global.banco.buscarAdmin({email,senha});
  
    if (admin.admcodigo)
    {
      global.adminCodigo = admin.admcodigo;
      global.adminEmail = admin.admemail;
      res.redirect('/admin/gerenciamento_curso');
    }
    else
    {
      res.redirect('/admin');
      res.render('admin/erro',{erro : "Credencial inválida"});
    }
  
  });

//POST Curso novo
router.post('/cursos_novo', verLogin, async (req, res, next) => {
    const { curnome, curdescricao, curcategoria, curhoras, curpreco } = req.body;
    
      if (!curnome || !curdescricao || !curcategoria || !curhoras || !curpreco)
  {
    return res.render('admin/cursos_novo',{
      admNome : global.admNome,
      mensagem : "Todos os campos devem ser preenchidos",
      sucesso : false
    });
  }
    await adminInserirCurso(curnome, curdescricao, curcategoria, curhoras, curpreco);
    return res.render('admin/cursos_novo',{
      admNome : global.admNome,
      mensagem : "Curso cadastrada com sucesso.",
      sucesso : true
  });
});
 


  
  function verificarLogin(res)
  {
    if (!global.adminEmail || global.adminEmail == "")
      res.redirect('/admin/');
  }
  
  
  function verLogin(req, res, next)
  {
    if (!global.adminEmail || global.adminEmail == "") 
      res.redirect('/admin/');
    next();
  }

module.exports = router;