var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/menu', function(req, res, next) {
  res.render('menu', { title: 'Express' });
});


//GET cadastro
router.get('/cadastro', (req, res) => {
    res.render('cadastro', {
        mensagem: undefined,
        sucesso: false
    });
});

//POST Cadastro 
router.post('/cadastro', async function(req, res, next){
    const email = req.body.email;
    const senha = req.body.senha;

    // validação de campos vazios
    if (!email || !senha) {
        return res.render('cadastro', {
            admNome: global.admNome || 'Admin',
            mensagem: "Todos os campos devem ser preenchidos",
            sucesso: false
        });
    }
    
        await global.banco.CadastroUsuario(email, senha);
        return res.render('cadastro', {
            admNome: global.admNome || 'Admin',
            mensagem: "Usuário cadastrado com sucesso.",
            sucesso: true
        });
    
});
//Post Login
router.post('/login', async function(req, res, next){
  const email = req.body.email ;
  const senha = req.body.senha;

  const usuario = await global.banco.buscarUsuario({email,senha});

  if (usuario.usucodigo)
  {
    global.usuarioCodigo = usuario.usucodigo;
    global.usuarioEmail = usuario.usuemail;
    res.redirect('/menu');  
  }
  else
  {
    res.redirect('/');
  }

})

module.exports = router;  