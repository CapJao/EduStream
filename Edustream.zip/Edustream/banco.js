const mysql = require('mysql2/promise');

let conexao;

async function conectarBD() {
  if (!conexao) {
    conexao = await mysql.createConnection({
      host: 'localhost',
      port: 3306,
      user: 'root',
      password: '',
      database: 'edustream'
    });
    console.log('Conectou no MySQL!');
  }
  return conexao;
}

async function buscarUsuario(usuario) {
  const conn = await conectarBD();
  const sql = "SELECT * FROM usuarios WHERE usuemail=? AND ususenha=?;";
  const [usuarioEcontrado] = await conn.query(sql, [usuario.email, usuario.senha]);
  return usuarioEcontrado && usuarioEcontrado.length > 0 ? usuarioEcontrado[0] : {};
}

async function buscarAdmin(usuario) {
  const conn = await conectarBD();
  const sql = "SELECT * FROM admins WHERE admemail=? AND admsenha=?;";
  const [usuarioEcontrado] = await conn.query(sql, [usuario.email, usuario.senha]);
  return usuarioEcontrado && usuarioEcontrado.length > 0 ? usuarioEcontrado[0] : {};
}

async function CadastroUsuario(email, senha) {
  const conn = await conectarBD();
  const sql = "INSERT INTO usuarios (usuemail, ususenha) VALUES (?,?);";
  await conn.query(sql, [email, senha]);
}

async function adminInserirCurso(nome, descricao, categoria, horas, preco) {
  const conn = await conectarBD();
  const sql = "INSERT INTO cursos (curnome, curdescricao, curcategoria, curhoras, curpreco) VALUES (?,?,?,?,?);";
  await conn.query(sql, [nome, descricao, categoria, horas, preco]);
}

async function adminEditarCurso(id, nome, descricao, categoria, horas, preco) {
  const conn = await conectarBD();
  const sql = "UPDATE cursos SET curnome = ?, curdescricao = ?, curcategoria = ?, curhoras = ?, curpreco = ?WHERE id = ?;";
  await conn.query(sql, [nome, descricao, categoria, horas, preco, id]);
}


async function query(sql, params) {
  const conn = await conectarBD();
  return conn.query(sql, params);
}

async function end() {
  if (conexao) {
    await conexao.end();
    console.log('Conexão com MySQL encerrada.');
    conexao = null;
  }
}

// Conecta ao iniciar
conectarBD();

module.exports = { buscarUsuario, buscarAdmin, CadastroUsuario, adminInserirCurso, query, end };
