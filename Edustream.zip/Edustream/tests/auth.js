const db = require('../banco');
const jwt = require('jsonwebtoken');

async function loginUser(email, senha) {
  const [rows] = await db.query('SELECT * FROM usuarios WHERE usuemail = ?', [email]);

  if (!rows.length) {
    return { sucesso: false, mensagem: 'Credenciais inválidas' };
  }

  const usuario = rows[0];

  // Comparação direta de senha
  if (usuario.ususenha !== senha) {
    return { sucesso: false, mensagem: 'Credenciais inválidas' };
  }

  const token = jwt.sign(
    { id: usuario.usucodigo, email: usuario.usuemail },
    'seu_segredo',
    { expiresIn: '1h' }
  );

  return { sucesso: true, token };
}

module.exports = { loginUser };
