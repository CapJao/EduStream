const { loginUser } = require('./auth');
const db = require('../banco');

beforeAll(async () => {
  // Insere diretamente senha em texto puro
  await db.query('INSERT INTO usuarios (usuemail, ususenha) VALUES (?, ?)', ['testes@gmail.com', '123']);
});

afterAll(async () => {
  //await db.query('DELETE FROM usuarios WHERE usuemail = ?', ['rafael@gmail.com']);
  await db.end();
});

describe('Testes de login', () => {
  test('Login com credenciais corretas deve retornar sucesso', async () => {
    const resultado = await loginUser('testes@gmail.com', '123');
    expect(resultado.sucesso).toBe(true);
    expect(resultado.token).toBeDefined();
  });

  test('Login com senha incorreta deve falhar', async () => {
    const resultado = await loginUser('testes@gmail.com', 'senhaErrada');
    expect(resultado.sucesso).toBe(false);
    expect(resultado.mensagem).toBe('Credenciais inválidas');
  });

  test('Login com email inexistente deve falhar', async () => {
    const resultado = await loginUser('naoexiste@exemplo.com', 'qualquer');
    expect(resultado.sucesso).toBe(false);
    expect(resultado.mensagem).toBe('Credenciais inválidas');
  });
});
