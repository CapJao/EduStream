const { adminEditarCurso } = require('../db/cursoService');

jest.mock('../db/cursoService', () => {
  const original = jest.requireActual('../db/cursoService');
  return {
    ...original,
    conectarBD: jest.fn(),
  };
});

const { conectarBD } = require('../db/cursoService');

describe('Função adminEditarCurso', () => {
  test('deve executar o UPDATE com os parâmetros corretos', async () => {
    const mockQuery = jest.fn();
    conectarBD.mockResolvedValue({ query: mockQuery });

    const id = 5;
    const nome = 'Curso Atualizado';
    const descricao = 'Descrição atualizada';
    const categoria = 'Programação';
    const horas = 40;
    const preco = 199.99;

    await adminEditarCurso(id, nome, descricao, categoria, horas, preco);

    expect(mockQuery).toHaveBeenCalledWith(
      expect.stringContaining('UPDATE cursos'),
      [nome, descricao, categoria, horas, preco, id]
    );
  });
});
