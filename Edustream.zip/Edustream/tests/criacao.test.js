const request = require('supertest');
const express = require('express');
const app = express();

// Middleware de parse
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// Mock do global admin (simulando login)
global.adminEmail = 'admin@teste.com';
global.admNome = 'Administrador';

// Mock da função de inserção
const mockInserirCurso = jest.fn();

// Substituir a função original pela mock
jest.mock('../caminho/do/arquivo/que/contem/adminInserirCurso', () => ({
  adminInserirCurso: (...args) => mockInserirCurso(...args),
}));

// Importa sua rota já com as funções mockadas
const adminRoutes = require('../routes/admin'); // atualize o caminho conforme seu projeto
app.use('/admin', adminRoutes);

describe('Testes da rota POST /admin/cursos_novo', () => {
  beforeEach(() => {
    mockInserirCurso.mockClear();
  });

  test('Criação de curso com sucesso', async () => {
    const res = await request(app)
      .post('/admin/cursos_novo')
      .send({
        curnome: 'Curso Teste',
        curdescricao: 'Descrição teste',
        curcategoria: 'Programação',
        curhoras: 40,
        curpreco: 200
      });

    expect(mockInserirCurso).toHaveBeenCalledWith(
      'Curso Teste',
      'Descrição teste',
      'Programação',
      '40',
      '200'
    );

    expect(res.text).toContain('Curso cadastrada com sucesso.');
  });

  test('Erro ao enviar com campo vazio', async () => {
    const res = await request(app)
      .post('/admin/cursos_novo')
      .send({
        curnome: '',
        curdescricao: 'Descrição teste',
        curcategoria: 'Programação',
        curhoras: 40,
        curpreco: 200
      });

    expect(mockInserirCurso).not.toHaveBeenCalled();
    expect(res.text).toContain('Todos os campos devem ser preenchidos');
  });
});
